The license included in this directory is for
[HTML5 Boiler Plate](http://html5boilerplate.com). Some of the HTML and CSS 
used here is derived from that project.
