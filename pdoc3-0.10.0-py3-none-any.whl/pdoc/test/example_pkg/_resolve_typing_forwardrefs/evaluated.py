from typing import Set


class Foo:
    bar: Set["Bar"]  # noqa: F821
