"""
```python
    .. include:: _include_me.py
        :start-line: 1
        :end-line: 2
```

.. include:: foo/../_include_me.py
    :start-after: =
    :end-before: 4
"""
