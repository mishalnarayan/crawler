from ..a import A
from .c import C


class B(A, C):
    pass
