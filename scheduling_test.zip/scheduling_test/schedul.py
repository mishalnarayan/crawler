import inspect
import os
import time
import subprocess
import datetime
from pytz import utc
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.executors.pool import ThreadPoolExecutor, ProcessPoolExecutor
import logging
# logging.basicConfig()
# logging.getLogger('apscheduler').setLevel(logging.DEBUG)

scheduler = BackgroundScheduler(executors={'processpool': ProcessPoolExecutor(max_workers=10),
										'default' : ThreadPoolExecutor(max_workers=20)})

def reporting_script_execution(proj_root_path,subprocess_result,project_name = False,retrying = False) :
	todays_date = str(datetime.datetime.now()).split(" ")[0]
	execution_logs_path = os.path.join(proj_root_path, "logs", "scheduling_execution_logs/")
	execution_log_file = os.path.join(execution_logs_path,"log_{}.txt".format(todays_date))

	if not os.path.isdir(execution_logs_path) :
		os.makedirs(execution_logs_path)
	
	with open(execution_log_file,"a") as f :
		f.write(subprocess_result.stdout)
		f.write(subprocess_result.stderr)
		f.write("script completion time = " + str(datetime.datetime.now()) + "\n")

	if subprocess_result.returncode != 0 and retrying == False:
		#todo email_log here explainig project name failed with 
		print(subprocess_result.stdout)
		pass

def executor(script_path, proj_root_path = False, retry_limit = 0, project_name = False) :
	if not proj_root_path :
		proj_root_path = os.path.dirname(script_path)

	try_again = True
	retry_count = 0
	while try_again :
		result = subprocess.run(['python3', script_path], cwd = proj_root_path, capture_output=True, text=True)
		if result.returncode == 0 :
			try_again = False

		if try_again and retry_count <= retry_limit :
			reporting_script_execution(proj_root_path,result,retrying = True)
			time.sleep(5)

		retry_count = retry_count + 1

	reporting_script_execution(proj_root_path,result)


#Add scheduled script config here

@scheduler.scheduled_job('interval', seconds=25,executor = 'processpool', coalesce = True, misfire_grace_time = None)
def proj1() :
	executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj1/work_script.py")


@scheduler.scheduled_job('interval', seconds=25,executor = 'processpool', coalesce = True, misfire_grace_time = None)	
def proj2() :
	executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj2/work_script.py")


@scheduler.scheduled_job('interval', seconds=25,executor = 'processpool', coalesce = True, misfire_grace_time = None)
def proj3() :
	executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj3/work_script.py")


@scheduler.scheduled_job('interval', seconds=25,executor = 'processpool', coalesce = True, misfire_grace_time = None)
def proj4() :
	executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj4/work_script.py")


@scheduler.scheduled_job('interval', seconds=25,executor = 'processpool', coalesce = True, misfire_grace_time = None)
def proj5() :
	executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj5/work_script.py")


@scheduler.scheduled_job('interval', seconds=25,executor = 'processpool', coalesce = True, misfire_grace_time = None)
def proj6() :
	executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj6/work_script.py")


@scheduler.scheduled_job('interval', seconds=25,executor = 'processpool', coalesce = True, misfire_grace_time = None)
def proj7() :
	executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj7/work_script.py")


@scheduler.scheduled_job('interval', seconds=25,executor = 'processpool', coalesce = True, misfire_grace_time = None)
def proj8() :
	executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj8/work_script.py")


@scheduler.scheduled_job('interval', seconds=25,executor = 'processpool', coalesce = True, misfire_grace_time = None)
def proj9() :
	executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj9/work_script.py")


@scheduler.scheduled_job('interval', seconds=25,executor = 'processpool', coalesce = True, misfire_grace_time = None)
def proj10() :
	executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj10/work_script.py")


if __name__ == '__main__':

	#scheduler.add_job(job_function, 'cron', day_of_week='mon-fri', hour=5, minute=30, end_date='2014-05-30')
    # scheduler.add_job(proj1, 'interval', seconds=5, executor = 'processpool')
    # scheduler.add_job(proj2, 'interval', seconds=5)

    scheduler.start()
    print('Press Ctrl+{0} to exit'.format('Break' if os.name == 'nt' else 'C'))
	# Runs an infinite loop
    try:
        # This is here to simulate application activity (which keeps the main thread alive).
        while True:
            time.sleep(0.1)
    except (KeyboardInterrupt, SystemExit):
        # Not strictly necessary if daemonic mode is enabled but should be done if possible
        scheduler.shutdown()