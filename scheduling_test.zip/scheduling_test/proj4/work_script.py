import os
from datetime import datetime
import time
# datetime object containing current date and time
now = datetime.now()
 
print("now =", now)

# dd/mm/YY H:M:S
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
print("sleeping")
time.sleep(20)
with open("output.txt","a") as f :
	f.write("current execution time:" + str(dt_string) + "\n")