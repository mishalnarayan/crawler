import logging
from datetime import datetime
import os
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.schedulers.background import BlockingScheduler
from apscheduler.executors.pool import ThreadPoolExecutor, ProcessPoolExecutor
from apschedulerui.web import SchedulerUI
from pytz import utc
import logging
import time
os.environ['TZ'] = 'UTC'
time.tzset()
logging.basicConfig(level=logging.DEBUG)

scheduler = BackgroundScheduler(executors={'processpool': ProcessPoolExecutor(max_workers=2),
                                        'default' : ThreadPoolExecutor(max_workers=20)})

ui = SchedulerUI(scheduler,capabilities = {'pause_job': True,'remove_job': True,'pause_scheduler': True,'stop_scheduler': True,'run_job': True,})
ui.start(port=9000)  # Server is now running in a *background* thread.
def name(a) :
    time.sleep(10)
    print(a)


scheduler.add_job(print, 'interval', args=['Job executed'], seconds=20, next_run_time=datetime.now())
scheduler.add_job(print, 'interval', args=['Job executed'], seconds=10, next_run_time=datetime.now())
scheduler.add_job(print, 'interval', args=['Job executed'], seconds=25, next_run_time=datetime.now())
scheduler.add_job(print, 'interval', args=['Job executed'], seconds=15, next_run_time=datetime.now())
scheduler.add_job(print, 'interval', args=['Job executed'], seconds=13, next_run_time=datetime.now())
scheduler.add_job(name, 'interval', args=['Job executed'], seconds=30, next_run_time=datetime.now())
scheduler.add_job(name, 'cron',args=['Job executed'],day_of_week='mon-fri', hour=14, minute=10, second=0,executor = 'processpool')
#scheduler.start()  # We need to call the blocking scheduler start method to prevent the script from exiting.

if __name__ == '__main__':

    #scheduler.add_job(job_function, 'cron', day_of_week='mon-fri', hour=5, minute=30, end_date='2014-05-30')
    # scheduler.add_job(proj1, 'interval', seconds=5, executor = 'processpool')
    # scheduler.add_job(proj2, 'interval', seconds=5)

    scheduler.start()
    print('Press Ctrl+{0} to exit'.format('Break' if os.name == 'nt' else 'C'))
    # Runs an infinite loop
    try:
        # This is here to simulate application activity (which keeps the main thread alive).
        while True:
            time.sleep(0.1)
    except (KeyboardInterrupt, SystemExit):
        # Not strictly necessary if daemonic mode is enabled but should be done if possible
        scheduler.shutdown()


# import inspect
# import os
# import time
# import subprocess
# import datetime
# from pytz import utc
# from apscheduler.schedulers.background import BackgroundScheduler
# from apscheduler.schedulers.background import BlockingScheduler
# from apscheduler.executors.pool import ThreadPoolExecutor, ProcessPoolExecutor
# from apschedulerui.web import SchedulerUI
# from pytz import utc
# import logging
# import time
# os.environ['TZ'] = 'UTC'
# time.tzset()
# # logging.basicConfig()
# # logging.getLogger('apscheduler').setLevel(logging.DEBUG)

# scheduler = BlockingScheduler(executors={'processpool': ProcessPoolExecutor(max_workers=10),
#                                         'default' : ThreadPoolExecutor(max_workers=20)})

# ui = SchedulerUI(scheduler,capabilities = {'pause_job': True,'remove_job': True,'pause_scheduler': True,'stop_scheduler': True,'run_job': True,})

# ui.start(port=9000)

# def reporting_script_execution(proj_root_path,subprocess_result,project_name = False,retrying = False) :
#     todays_date = str(datetime.datetime.now()).split(" ")[0]
#     execution_logs_path = os.path.join(proj_root_path, "logs", "scheduling_execution_logs/")
#     execution_log_file = os.path.join(execution_logs_path,"log_{}.txt".format(todays_date))

#     if not os.path.isdir(execution_logs_path) :
#         os.makedirs(execution_logs_path)
    
#     with open(execution_log_file,"a") as f :
#         f.write(subprocess_result.stdout)
#         f.write(subprocess_result.stderr)
#         f.write("script completion time = " + str(datetime.datetime.now()) + "\n")

#     if subprocess_result.returncode != 0 and retrying == False:
#         #todo email_log here explainig project name failed with 
#         print(subprocess_result.stdout)
#         pass

# def executor(script_path, proj_root_path = False, retry_limit = 0, project_name = False) :
#     if not proj_root_path :
#         proj_root_path = os.path.dirname(script_path)

#     try_again = True
#     retry_count = 0
#     while try_again :
#         result = subprocess.run(['python3', script_path], cwd = proj_root_path, capture_output=True, text=True)
#         if result.returncode == 0 :
#             try_again = False

#         if try_again and retry_count <= retry_limit :
#             reporting_script_execution(proj_root_path,result,retrying = True)
#             time.sleep(5)

#         retry_count = retry_count + 1

#     reporting_script_execution(proj_root_path,result)


# #Add scheduled script config here

# @scheduler.scheduled_job('cron',day_of_week='mon-fri', hour=1, minute=0, second=0,next_run_time=datetime.datetime.now(), executor = 'processpool', coalesce = True, misfire_grace_time = None)
# def proj1() :
#     executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj1/work_script.py")


# @scheduler.scheduled_job('cron',day_of_week='mon-fri', hour=2, minute=0, second=0,next_run_time=datetime.datetime.now(), executor = 'processpool', coalesce = True, misfire_grace_time = None)   
# def proj2() :
#     executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj2/work_script.py")


# @scheduler.scheduled_job('cron',day_of_week='mon-fri', hour=3, minute=0, second=0,next_run_time=datetime.datetime.now(), executor = 'processpool', coalesce = True, misfire_grace_time = None)
# def proj3() :
#     executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj3/work_script.py")


# @scheduler.scheduled_job('cron',day_of_week='mon-fri', hour=4, minute=0, second=0,next_run_time=datetime.datetime.now(), executor = 'processpool', coalesce = True, misfire_grace_time = None)
# def proj4() :
#     executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj4/work_script.py")


# @scheduler.scheduled_job('cron',day_of_week='mon-fri', hour=5, minute=0, second=0,next_run_time=datetime.datetime.now(), executor = 'processpool', coalesce = True, misfire_grace_time = None)
# def proj5() :
#     executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj5/work_script.py")


# @scheduler.scheduled_job('cron',day_of_week='mon-fri', hour=6, minute=0, second=0,next_run_time=datetime.datetime.now(), executor = 'processpool', coalesce = True, misfire_grace_time = None)
# def proj6() :
#     executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj6/work_script.py")


# @scheduler.scheduled_job('cron',day_of_week='mon-fri', hour=7, minute=0, second=0,next_run_time=datetime.datetime.now(), executor = 'processpool', coalesce = True, misfire_grace_time = None)
# def proj7() :
#     executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj7/work_script.py")


# @scheduler.scheduled_job('cron',day_of_week='mon-fri', hour=8, minute=0, second=0,next_run_time=datetime.datetime.now(), executor = 'processpool', coalesce = True, misfire_grace_time = None)
# def proj8() :
#     executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj8/work_script.py")


# @scheduler.scheduled_job('cron',day_of_week='mon-fri', hour=9, minute=0, second=0,next_run_time=datetime.datetime.now(), executor = 'processpool', coalesce = True, misfire_grace_time = None)
# def proj9() :
#     executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj9/work_script.py")


# @scheduler.scheduled_job('cron',day_of_week='mon-fri', hour=11, minute=0, second=0,next_run_time=datetime.datetime.now(), executor = 'processpool', coalesce = True, misfire_grace_time = None)
# def proj10() :
#     executor("/Users/ujjawalnarayan/desktop/scheduling_test/proj10/work_script.py")


# scheduler.start()

# if __name__ == '__main__':

#     #scheduler.add_job(job_function, 'cron', day_of_week='mon-fri', hour=5, minute=30, end_date='2014-05-30')
#     # scheduler.add_job(proj1, 'interval', seconds=5, executor = 'processpool')
#     # scheduler.add_job(proj2, 'interval', seconds=5)

#     scheduler.start()
#     print('Press Ctrl+{0} to exit'.format('Break' if os.name == 'nt' else 'C'))
#     # Runs an infinite loop
#     try:
#         # This is here to simulate application activity (which keeps the main thread alive).
#         while True:
#             time.sleep(0.1)
#     except (KeyboardInterrupt, SystemExit):
#         # Not strictly necessary if daemonic mode is enabled but should be done if possible
#         scheduler.shutdown()


# Flask-SocketIO==4.3.1
# python-engineio==3.13.2
# python-socketio==4.6.0

# Requirement already satisfied: Flask-SocketIO in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (5.3.1)
# Requirement already satisfied: python-socketio>=5.0.2 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from Flask-SocketIO) (5.7.2)
# Requirement already satisfied: Flask>=0.9 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from Flask-SocketIO) (2.2.2)
# Requirement already satisfied: Jinja2>=3.0 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from Flask>=0.9->Flask-SocketIO) (3.1.2)
# Requirement already satisfied: importlib-metadata>=3.6.0 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from Flask>=0.9->Flask-SocketIO) (4.8.2)
# Requirement already satisfied: click>=8.0 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from Flask>=0.9->Flask-SocketIO) (8.0.3)
# Requirement already satisfied: Werkzeug>=2.2.2 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from Flask>=0.9->Flask-SocketIO) (2.2.2)
# Requirement already satisfied: itsdangerous>=2.0 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from Flask>=0.9->Flask-SocketIO) (2.1.2)
# Requirement already satisfied: bidict>=0.21.0 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from python-socketio>=5.0.2->Flask-SocketIO) (0.22.0)
# Requirement already satisfied: python-engineio>=4.3.0 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from python-socketio>=5.0.2->Flask-SocketIO) (4.3.4)
# Requirement already satisfied: zipp>=0.5 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from importlib-metadata>=3.6.0->Flask>=0.9->Flask-SocketIO) (3.6.0)
# Requirement already satisfied: MarkupSafe>=2.0 in /Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages (from Jinja2>=3.0->Flask>=0.9->Flask-SocketIO) (2.1.1)