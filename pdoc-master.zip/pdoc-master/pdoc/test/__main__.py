#!/usr/bin/env python3
import unittest

if __name__ == "__main__":
    unittest.main(module='__init__')
