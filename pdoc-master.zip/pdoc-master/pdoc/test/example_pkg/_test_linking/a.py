class A:
    def a(self):
        """a"""
