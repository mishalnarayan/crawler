class C:
    def c(self):
        """c"""
