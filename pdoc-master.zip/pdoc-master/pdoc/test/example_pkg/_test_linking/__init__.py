pass  # Avoids OSError on `inspect.getsource(doc_obj.obj)` in `pdoc._var_docstrings`
