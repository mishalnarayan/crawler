from a.util import C


class D(C):
    pass
