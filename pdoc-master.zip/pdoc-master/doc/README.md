pdoc Documentation
==================
Build HTML documentation by running:

    ./build.sh
    
The docs will appear in _./build_ directory.
