<!--
NOTE: Only submit issues for Python package "pdoc3" on PyPI.
Python package "pdoc" lives elsewhere.
-->


### Expected Behavior



### Actual Behavior



### Steps to Reproduce

1.
2.
3.


### Additional info

- pdoc version:
